# Gohar.tech Portfolio — Setup & Deployment

A responsive, static portfolio built with HTML, CSS, and JavaScript. No Node.js, database, or build command is required.

## Folder contents
- `index.html` — all portfolio content and SEO metadata
- `style.css` — layout, responsive design, project illustrations, animations
- `script.js` — mobile menu, scroll progress, reveal effects, back-to-top button
- `assets/gohar-profile.jpg` — supplied profile photo
- `assets/Gohar_Rehman_Resume.pdf` — CV download (add your original CV here)

## 1. Run on Windows
1. Extract `gohar-tech-portfolio.zip`.
2. Open the extracted `gohar-tech-portfolio` folder in Visual Studio Code.
3. Recommended: install the VS Code extension **Live Server**.
4. Right-click `index.html` and choose **Open with Live Server**.
5. If you do not want an extension, double-click `index.html` to open it in a browser. A local web server is more reliable.

## 2. Add your CV PDF
Copy your actual PDF into the `assets` folder and name it exactly:
`Gohar_Rehman_Resume.pdf`
The Download CV button links to that path. Keep the filename exactly the same.

## 3. Review before publishing
- Confirm phone/email, education wording, internship details, project descriptions and links.
- Replace project illustration placeholders with genuine screenshots when you have them.
- The project visuals in this starter are CSS illustrations, not real screenshots of the running apps.
- Add actual repository URLs for each project. The current Auto Rescue repository link is based on the GitHub link supplied in prior project context; verify it before publishing.
- If a technology or feature is only planned/partially implemented, describe it accurately.

## 4. Publish for free using GitHub Pages
1. Sign in at https://github.com and create a new **public** repository named `gohar-tech-portfolio`.
2. Upload all files and folders from inside this project folder (not the ZIP itself). Keep `index.html` at the repository root.
3. Open repository **Settings → Pages**.
4. Under Build and deployment, select **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then Save.
6. Wait for the deployment. GitHub will show a published URL, usually:
   `https://YOUR-USERNAME.github.io/gohar-tech-portfolio/`
7. Open that URL on your phone and computer to test all links and the CV download.

## 5. Connect the custom domain gohar.tech
You must register the domain if it is available and you own it. Do not add DNS records until the domain registrar and GitHub Pages instructions are visible.
1. In GitHub repository Settings → Pages → Custom domain, enter `gohar.tech` and Save.
2. At your domain registrar, add the exact DNS records GitHub Pages currently recommends. For an apex domain these commonly include A records for GitHub Pages; for `www`, a CNAME is typically used. Follow the current GitHub documentation exactly.
3. Enable Enforce HTTPS after DNS verification is complete.
4. Test both `https://gohar.tech` and `https://www.gohar.tech` if you configure both.

Official guide: https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site

## 6. Help Google discover it
1. Publish the site and verify the domain in Google Search Console: https://search.google.com/search-console
2. Submit `https://gohar.tech/sitemap.xml` after adding a sitemap (see next step) or use URL Inspection to request indexing.
3. Keep the name, title, description, project content and public profiles consistent.
4. Google indexing can take days or longer. Search appearance/ranking is not guaranteed.

## 7. Important next improvements
- Add `sitemap.xml` and `robots.txt` using the final live domain.
- Add real project screenshots and project-specific GitHub repository links.
- Add dates for TriSoft internships.
- Add actual project outcomes, screenshots, demo links and technologies verified from your code.
- Never publish secrets, API keys, passwords, private Firebase config or sensitive user data.
